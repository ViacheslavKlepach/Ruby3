require 'rspec'
require 'selenium-webdriver'
require 'page-object'

World(PageObject::PageFactory) # This is for on and visit